# NEON CONTROL — iOS Cloud Build

โปรเจกต์นี้เตรียมไว้สำหรับ build บน Codemagic โดยไม่ต้องมี Mac อยู่กับผู้ใช้

## สิ่งที่มีให้แล้ว
- Native iOS SwiftUI app
- WKWebView โหลด `NEON_CONTROL.html`
- CoreBluetooth bridge สำหรับ OBD2 BLE
- Shared Xcode scheme: `NEON_CONTROL_iOS`
- `codemagic.yaml` สำหรับสร้าง development IPA
- Bundle ID: `com.neoncontrol.pcx160`

## ก่อน Build จริง
การติดตั้งลง iPhone จริงต้องมี Apple Developer Program และการ signing ที่ถูกต้อง

### วิธีใช้งานบน Codemagic
1. สร้าง GitHub repository ใหม่ เช่น `NEON_CONTROL_iOS`
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ขึ้น repository โดยให้ `codemagic.yaml` อยู่ที่ root
3. ใน Codemagic: Add application → เชื่อม GitHub → เลือก repository
4. ตั้งค่า App Store Connect API integration ตามระบบของ Codemagic
5. ตั้ง Code signing identities / provisioning profile ให้ Bundle ID `com.neoncontrol.pcx160`
6. เปลี่ยน `YOUR_APP_STORE_CONNECT_KEY_NAME` ใน `codemagic.yaml` เป็นชื่อ integration จริง
7. Start new build
8. เมื่อสำเร็จ ดาวน์โหลด `.ipa` จาก Artifacts

## สำหรับการทดสอบเครื่องตัวเอง
Workflow ปัจจุบันใช้ `distribution_type: development` ซึ่งต้องใช้ Development provisioning profile ที่มี iPhone ของผู้ทดสอบอยู่ใน profile

ถ้าจะใช้ TestFlight ให้เปลี่ยนเป็น `distribution_type: app_store` และใช้ App Store Connect/TestFlight workflow แทน

## สำคัญ
อย่าใส่ Apple password, private key หรือ `.p8` ลงใน GitHub repository หรือใน `codemagic.yaml` ให้เก็บผ่าน Codemagic secrets/integrations เท่านั้น
