import Foundation
import CoreBluetooth
import Combine

final class ODBluetoothManager: NSObject, ObservableObject {
    // Generic BLE UART UUIDs used by many ELM327-style adapters.
    private let serviceUUID = CBUUID(string: "FFE0")
    private let characteristicUUID = CBUUID(string: "FFE1")

    private var central: CBCentralManager!
    private var peripheral: CBPeripheral?
    private var characteristic: CBCharacteristic?
    private var rxBuffer = ""
    private var scanTimer: DispatchWorkItem?

    @Published private(set) var connected = false

    override init() {
        super.init()
        central = CBCentralManager(delegate: self, queue: .main)
    }

    func startScan() {
        guard central.state == .poweredOn else {
            emit("error", ["message": "Bluetooth ยังไม่พร้อมใช้งาน"])
            return
        }

        if let p = peripheral {
            central.cancelPeripheralConnection(p)
        }
        peripheral = nil
        characteristic = nil
        rxBuffer = ""

        emit("scanning")
        // Scan without a service filter because some adapters do not advertise FFE0.
        central.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])

        scanTimer?.cancel()
        let task = DispatchWorkItem { [weak self] in
            guard let self else { return }
            self.central.stopScan()
            if self.peripheral == nil {
                self.emit("error", ["message": "ไม่พบ OBD2 BLE — ตรวจสอบว่าอะแดปเตอร์เปิดอยู่"])
            }
        }
        scanTimer = task
        DispatchQueue.main.asyncAfter(deadline: .now() + 12, execute: task)
    }

    func disconnect() {
        scanTimer?.cancel()
        central.stopScan()
        if let p = peripheral { central.cancelPeripheralConnection(p) }
        connected = false
        characteristic = nil
        emit("disconnected")
    }

    func send(_ command: String) {
        guard let p = peripheral, let c = characteristic else {
            emit("error", ["message": "ยังไม่ได้เชื่อมต่อ OBD2"])
            return
        }
        let clean = command.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        let data = Data((clean + "\r").utf8)
        let type: CBCharacteristicWriteType = c.properties.contains(.writeWithoutResponse) ? .withoutResponse : .withResponse
        p.writeValue(data, for: c, type: type)
    }

    private func emit(_ event: String, _ payload: [String: Any] = [:]) {
        var obj: [String: Any] = ["event": event]
        payload.forEach { obj[$0.key] = $0.value }
        guard JSONSerialization.isValidJSONObject(obj),
              let data = try? JSONSerialization.data(withJSONObject: obj),
              let json = String(data: data, encoding: .utf8) else { return }
        let js = "window.dispatchEvent(new CustomEvent('neonNativeOBD',{detail:\(json)}));"
        DispatchQueue.main.async {
            NotificationCenter.default.post(name: .neonWebJS, object: js)
        }
    }

    private func handleIncoming(_ data: Data) {
        guard let chunk = String(data: data, encoding: .utf8) else { return }
        rxBuffer += chunk
        let parts = rxBuffer.split(separator: ">", omittingEmptySubsequences: false)
        if parts.count > 1 {
            for part in parts.dropLast() {
                let text = part.trimmingCharacters(in: .whitespacesAndNewlines)
                if !text.isEmpty { emit("data", ["text": text]) }
            }
            rxBuffer = String(parts.last!)
        }
    }
}

extension ODBluetoothManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        emit("bluetoothState", ["state": central.state.rawValue])
        if central.state == .poweredOn {
            emit("bluetoothReady")
        }
    }

    func centralManager(_ central: CBCentralManager,
                        didDiscover peripheral: CBPeripheral,
                        advertisementData: [String : Any],
                        rssi RSSI: NSNumber) {
        let name = peripheral.name ?? (advertisementData[CBAdvertisementDataLocalNameKey] as? String) ?? "Unknown"
        let upper = name.uppercased()
        let advertisedServices = (advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID]) ?? []
        let looksLikeOBD = upper.contains("OBD") || upper.contains("ELM") || upper.contains("V-LINK") || upper.contains("VLINK") || advertisedServices.contains(serviceUUID)
        guard looksLikeOBD else { return }

        self.peripheral = peripheral
        central.stopScan()
        scanTimer?.cancel()
        peripheral.delegate = self
        emit("deviceFound", ["name": name])
        central.connect(peripheral, options: nil)
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        connected = true
        emit("connected", ["name": peripheral.name ?? "OBD2 BLE"])
        peripheral.discoverServices(nil)
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        connected = false
        characteristic = nil
        emit("error", ["message": error?.localizedDescription ?? "เชื่อมต่อ OBD2 ไม่สำเร็จ"])
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        connected = false
        characteristic = nil
        rxBuffer = ""
        emit("disconnected")
    }
}

extension ODBluetoothManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard error == nil else {
            emit("error", ["message": error!.localizedDescription])
            return
        }

        let services = peripheral.services ?? []
        if let service = services.first(where: { $0.uuid == serviceUUID }) {
            peripheral.discoverCharacteristics(nil, for: service)
            return
        }

        // Fallback: try every primary service; some adapters use a custom UUID.
        for service in services {
            peripheral.discoverCharacteristics(nil, for: service)
        }
    }

    func peripheral(_ peripheral: CBPeripheral,
                    didDiscoverCharacteristicsFor service: CBService,
                    error: Error?) {
        guard error == nil else { return }
        guard characteristic == nil else { return }

        let chars = service.characteristics ?? []
        let selected = chars.first(where: { $0.uuid == characteristicUUID })
            ?? chars.first(where: { $0.properties.contains(.write) || $0.properties.contains(.writeWithoutResponse) })
        guard let c = selected else { return }

        characteristic = c
        if c.properties.contains(.notify) || c.properties.contains(.indicate) {
            peripheral.setNotifyValue(true, for: c)
        }

        emit("ready")

        // ELM327 initialization sequence.
        ["AT Z", "AT E0", "AT L0", "AT S0", "AT H0", "AT SP 0"].enumerated().forEach { index, cmd in
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.35) { [weak self] in
                self?.send(cmd)
            }
        }
    }

    func peripheral(_ peripheral: CBPeripheral,
                    didUpdateValueFor characteristic: CBCharacteristic,
                    error: Error?) {
        if let error {
            emit("error", ["message": error.localizedDescription])
            return
        }
        if let data = characteristic.value { handleIncoming(data) }
    }
}

extension Notification.Name {
    static let neonWebJS = Notification.Name("neonWebJS")
}
