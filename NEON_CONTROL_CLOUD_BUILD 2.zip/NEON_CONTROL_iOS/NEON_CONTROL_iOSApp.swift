import SwiftUI

@main
struct NEON_CONTROL_iOSApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
