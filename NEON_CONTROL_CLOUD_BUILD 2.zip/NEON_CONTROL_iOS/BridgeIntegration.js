// Native iOS bridge for NEON CONTROL.
// The HTML calls window.neonNative instead of navigator.bluetooth when hosted by WKWebView.
(function () {
  const $ = id => document.getElementById(id);

  function setConnectionUI(connected) {
    window.isConnected = !!connected;
    const btn = $('connectBtn');
    if (btn) {
      btn.innerText = connected ? 'ตัดการเชื่อมต่อ' : 'เชื่อมต่อ OBD2 BLUETOOTH';
      btn.className = connected ? 'btn btn-danger' : 'btn btn-connect';
    }
    const dot = $('connDot');
    const text = $('connText');
    const ecu = $('ecuStatusText');
    if (dot) dot.className = connected ? 'dot connected' : 'dot';
    if (text) text.innerText = connected ? 'CONNECTED' : 'OFFLINE';
    if (ecu) ecu.innerText = connected ? 'ECU ONLINE' : 'ECU STANDBY';
  }

  window.addEventListener('neonNativeOBD', e => {
    const d = e.detail || {};
    if (d.event === 'scanning') {
      if (typeof logToConsole === 'function') logToConsole('กำลังค้นหาอุปกรณ์ Bluetooth OBD2...');
      const btn = $('connectBtn');
      if (btn) btn.innerText = '🔎 กำลังค้นหา OBD2...';
      return;
    }
    if (d.event === 'deviceFound') {
      if (typeof logToConsole === 'function') logToConsole('พบอุปกรณ์: ' + (d.name || 'OBD2 BLE'));
      return;
    }
    if (d.event === 'connected') {
      setConnectionUI(true);
      if (typeof logToConsole === 'function') logToConsole('เชื่อมต่อสำเร็จ! กำลังตั้งค่า ELM327...');
      return;
    }
    if (d.event === 'ready') {
      if (typeof logToConsole === 'function') logToConsole('OBD2 พร้อมใช้งาน');
      if (typeof startPolling === 'function') startPolling();
      return;
    }
    if (d.event === 'disconnected') {
      if (typeof onDisconnected === 'function') onDisconnected();
      else setConnectionUI(false);
      return;
    }
    if (d.event === 'error') {
      if (typeof logToConsole === 'function') logToConsole('OBD2: ' + (d.message || 'เกิดข้อผิดพลาด'));
      const btn = $('connectBtn');
      if (btn && !window.isConnected) btn.innerText = 'เชื่อมต่อ OBD2 BLUETOOTH';
      return;
    }
    if (d.event === 'data' && typeof window.processECUResponse === 'function') {
      window.processECUResponse(d.text || '');
    }
  });

  window.neonNative = {
    connect: () => window.webkit?.messageHandlers?.nativeOBD?.postMessage({ action: 'connect' }),
    disconnect: () => window.webkit?.messageHandlers?.nativeOBD?.postMessage({ action: 'disconnect' }),
    send: command => window.webkit?.messageHandlers?.nativeOBD?.postMessage({ action: 'send', command })
  };

  window.isIOSNativeOBD = !!window.webkit?.messageHandlers?.nativeOBD;
})();
