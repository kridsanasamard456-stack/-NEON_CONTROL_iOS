import SwiftUI
import WebKit

struct ContentView: View {
    @StateObject private var bluetooth = ODBluetoothManager()

    var body: some View {
        NeonWebView(bluetooth: bluetooth)
            .ignoresSafeArea()
    }
}

struct NeonWebView: UIViewRepresentable {
    @ObservedObject var bluetooth: ODBluetoothManager

    func makeCoordinator() -> Coordinator { Coordinator(bluetooth: bluetooth) }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let controller = WKUserContentController()
        controller.add(context.coordinator, name: "nativeOBD")
        config.userContentController = controller
        config.allowsInlineMediaPlayback = true

        let web = WKWebView(frame: .zero, configuration: config)
        web.isOpaque = false
        web.backgroundColor = .black
        web.scrollView.backgroundColor = .black
        context.coordinator.webView = web
        context.coordinator.observeNativeEvents()
        context.coordinator.loadHTML()
        return web
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKScriptMessageHandler {
        weak var webView: WKWebView?
        let bluetooth: ODBluetoothManager
        private var observer: NSObjectProtocol?

        init(bluetooth: ODBluetoothManager) { self.bluetooth = bluetooth }

        deinit {
            if let observer { NotificationCenter.default.removeObserver(observer) }
        }

        func observeNativeEvents() {
            observer = NotificationCenter.default.addObserver(
                forName: .neonWebJS,
                object: nil,
                queue: .main
            ) { [weak self] note in
                guard let js = note.object as? String else { return }
                self?.webView?.evaluateJavaScript(js, completionHandler: nil)
            }
        }

        func loadHTML() {
            guard let url = Bundle.main.url(forResource: "NEON_CONTROL", withExtension: "html") else { return }
            webView?.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard let body = message.body as? [String: Any], let action = body["action"] as? String else { return }
            switch action {
            case "connect": bluetooth.startScan()
            case "disconnect": bluetooth.disconnect()
            case "send":
                if let command = body["command"] as? String { bluetooth.send(command) }
            default: break
            }
        }
    }
}
